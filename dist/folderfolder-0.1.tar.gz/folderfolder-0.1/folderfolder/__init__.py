__version__ = '0.1'
name = 'folderfolder'

from folderfolder.folderfolder import FolderFolder
FF = FolderFolder
